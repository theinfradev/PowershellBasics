<#
.SYNOPSIS
    Converts a PSCustomObject into a well-formatted JSON string.

.PARAMETER InputObject
    The PSCustomObject to convert.

.PARAMETER Depth
    If nested objects exist, the level of depth to use (default is four).

.PARAMETER IndentationSize
    The number of whitespace characters to use for indentation (default is four).
#>
function ConvertTo-PrettifiedJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true, ValueFromPipeline=$true)]
        [Object]
        $InputObject,

        [Parameter(Mandatory=$false)]
        [Int]
        $Depth = 4,

        [Parameter(Mandatory=$false)]
        [Int]
        $IndentationSize = 2
    )

    $CurrentIndentSize = 0;
    $EOL = [Environment]::NewLine;
    $PrettifiedJson = [String]::Empty;
    $RawJsonString = ConvertTo-Json -InputObject $InputObject -Depth $Depth;

    $RawJsonString -split $EOL | ForEach-Object {
        $CurrentLine = $_.TrimStart().Replace('  ', ' ');
        if ($CurrentLine -match '^(\}|\])') {
            $CurrentIndentSize -= $IndentationSize;
            $CurrentIndentSize = [Math]::Max(0, $CurrentIndentSize);
        }

        $LeadingWhitespace = (' ' * $CurrentIndentSize);
        $PrettifiedJson += "${LeadingWhitespace}${CurrentLine}${EOL}";

        if ($CurrentLine -match '(\{|\[)') {
            $CurrentIndentSize += $IndentationSize;
        }
    }

    return $PrettifiedJson;
}

Export-ModuleMember -Function ConvertTo-PrettifiedJson;
