<#
.SYNOPSIS
    A root PowerShell module file to indicate to PowerShell that this is a script package, and not a metadata package.
    For security reasons, this file cannot be empty.
#>

Get-ChildItem "${PSScriptRoot}/Functions" -Filter '*.ps1' | ForEach-Object {
    . $_.FullName;
}
