$Local:SUTPath = Get-Item "${PSScriptRoot}/..";
$Local:SUTName = $Local:SUTPath.BaseName;

Describe 'ConvertTo-PrettifiedJson Unit Tests' {
    BeforeAll { Import-Module "${SUTPath}" -Force -Scope Local; }

    InModuleScope "${SUTName}" {
        It 'Should not accept null values' {
            $ContinuedDespiteNullValue = $false;
            trap {
                ConvertTo-PrettifiedJson $null;
                $ContinuedDespiteNullValue = $true;
                continue;
            }

            $ContinuedDespiteNullValue | Should -Befalse;
        }

        It 'Should correctly indent nested JSON objects' {
            $RawObject = [PSCustomObject]@{
                levelTwo = [PSCustomObject]@{
                    levelThree = [PSCustomObject]@{
                        value = 'hello, world!';
                    };
                };
            };

            $PrettifiedJson = ConvertTo-PrettifiedJson $RawObject;
            $PrettifiedLines = $PrettifiedJson -split [Environment]::NewLine;
            $PrettifiedLines[0] | Should -Be '{';
            $PrettifiedLines[1] | Should -Be '  "levelTwo": {';
            $PrettifiedLines[2] | Should -Be '    "levelThree": {';
            $PrettifiedLines[3] | Should -Be '      "value": "hello, world!"';
            $PrettifiedLines[4] | Should -Be '    }';
            $PrettifiedLines[5] | Should -Be '  }';
            $PrettifiedLines[6] | Should -Be '}';
        }

        It 'Should correctly indent arrays in JSON objects' {
            $RawObject = [PSCustomObject]@{
                someValues = @(
                    [PSCustomObject]@{
                        name = 'test1';
                    },
                    [PSCustomObject]@{
                        name = 'test2';
                    },
                    @(
                        'test3',
                        'test4'
                    )
                );
            };

            $PrettifiedJson = ConvertTo-PrettifiedJson $RawObject;
            $PrettifiedLines = $PrettifiedJson -split [Environment]::NewLine;
            $PrettifiedLines[00] | Should -Be '{';
            $PrettifiedLines[01] | Should -Be '  "someValues": [';
            $PrettifiedLines[02] | Should -Be '    {';
            $PrettifiedLines[03] | Should -Be '      "name": "test1"';
            $PrettifiedLines[04] | Should -Be '    },';
            $PrettifiedLines[05] | Should -Be '    {';
            $PrettifiedLines[06] | Should -Be '      "name": "test2"';
            $PrettifiedLines[07] | Should -Be '    },';
            $PrettifiedLines[08] | Should -Be '    [';
            $PrettifiedLines[09] | Should -Be '      "test3",';
            $PrettifiedLines[10] | Should -Be '      "test4"';
            $PrettifiedLines[11] | Should -Be '    ]';
            $PrettifiedLines[12] | Should -Be '  ]';
            $PrettifiedLines[13] | Should -Be '}';
        }

        It 'Should accept objects to convert from pipeline' {
            $RawObject = [PSCustomObject]@{
                value = 7;
            };

            $PrettifiedJson = $RawObject | ConvertTo-PrettifiedJson;
            $PrettifiedLines = $PrettifiedJson -split [Environment]::NewLine;
            $PrettifiedLines[0] | Should -Be '{';
            $PrettifiedLines[1] | Should -Be '  "value": 7';
            $PrettifiedLines[2] | Should -Be '}';
        }
    }

    AfterAll { Remove-Module "${SUTName}" -Force -ErrorAction SilentlyContinue; }
}
